#ifndef __MEMCMP_P_H__
#define __MEMCMP_P_H__
#include <avr/pgmspace.h>

extern int memcmp_P(void *, PGM_VOID_P, size_t);

#endif // __MEMCMP_P_H__
