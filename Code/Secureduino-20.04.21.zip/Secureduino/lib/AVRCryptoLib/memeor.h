#ifndef __MEMXOR_P_H__
#define __MEMXOR_P_H__
#include <avr/pgmspace.h>

extern void *memeor(void *, void *, size_t);

#endif // __MEMXOR_P_H__
